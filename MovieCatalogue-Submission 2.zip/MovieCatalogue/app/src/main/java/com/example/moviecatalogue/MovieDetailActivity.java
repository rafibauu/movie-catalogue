package com.example.moviecatalogue;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

public class MovieDetailActivity extends AppCompatActivity {

    public static final String EXTRA_MOVIE = "extra_movie";

    TextView movieTitle;
    TextView movieRuntime;
    TextView movieDesc;
    ImageView moviePoster;
    ImageView movieBackground;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_detail);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        Movie movie = getIntent().getParcelableExtra(EXTRA_MOVIE);

        moviePoster = findViewById(R.id.moviesPoster);
        loadPoster(movie.getPoster(), moviePoster);

        movieBackground = findViewById(R.id.moviesBackground);
        movieRuntime = findViewById(R.id.moviesRuntime);

        fetchMovieDetail(movie.getId(), movie);

        movieTitle = findViewById(R.id.movieTitle);
        movieTitle.setText(movie.getName());

        movieDesc = findViewById(R.id.movieDescription);
        movieDesc.setText(movie.getDescription());

    }

    private void loadPoster(String url, ImageView imageView) {
        Picasso.get().load(url).into(imageView);
    }

    private String getDetailMovie(int id) {
        final String BASE_URL = "https://api.themoviedb.org/3/movie/";
        final String API_KEY = "ea8aa5120eed2fdb1d312cf637abf995";
        final String DETAIL_URL = BASE_URL + id + "?api_key=" + API_KEY;
        return DETAIL_URL;
    }

    private void fetchMovieDetail(int id, final Movie movie) {

        final ProgressDialog progress = new ProgressDialog(MovieDetailActivity.this);
        progress.setMessage("Fetching data...");
        progress.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                getDetailMovie(id),
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String runtime = jsonObject.getString("runtime");
                            movieRuntime.setText(runtime + " mins");

                            loadPoster(movie.getBackground(), movieBackground);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        progress.dismiss();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MovieDetailActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(MovieDetailActivity.this);
        requestQueue.add(stringRequest);

    }
}
