package com.example.moviecatalogue;


import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;
import com.synnapps.carouselview.CarouselView;
import com.synnapps.carouselview.ImageListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class TvFragment extends Fragment {

    private static final String URL_DATA = "https://api.themoviedb.org/3/tv/on_the_air?api_key=ea8aa5120eed2fdb1d312cf637abf995";
    private static final String URL_TV_POPULAR = "https://api.themoviedb.org/3/tv/popular?api_key=ea8aa5120eed2fdb1d312cf637abf995";

    private RecyclerView rvOnAirTv;
    private ArrayList<Tv> alOnAirTv;

    private RecyclerView rvPopularTv;
    private ArrayList<Tv> alPopularTv;

    CarouselView carouselView;
    String[] sampleImages = {"https://image.tmdb.org/t/p/w500/7AKhSfJHnVi0zXQS4eJirHDs22p.jpg", "https://image.tmdb.org/t/p/w500/piuRhGiQBYWgW668eSNJ2ug5uAO.jpg"};

    public ImageView setting;

    public TvFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_tv, container, false);
        view.setNestedScrollingEnabled(true);

        setting = view.findViewById(R.id.setting);
        setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Settings.ACTION_LOCALE_SETTINGS);
                getActivity().startActivity(intent);
            }
        });

        rvOnAirTv = view.findViewById(R.id.onAirTvList);
        rvOnAirTv.setHasFixedSize(true);

        rvPopularTv = view.findViewById(R.id.popularTvList);
        rvPopularTv.setHasFixedSize(true);

        fetchTvOnAir();
        fetchPopularTv();

        carouselView = view.findViewById(R.id.carouselView);
        carouselView.setPageCount(sampleImages.length);
        carouselView.setImageListener(imageListener);

        return view;
    }

    ImageListener imageListener = new ImageListener() {
        @Override
        public void setImageForPosition(int position, ImageView imageView) {
            Picasso
                    .get()
                    .load(sampleImages[position])
                    .into(imageView);
        }
    };

    private void fetchTvOnAir() {
        final ProgressDialog progress = new ProgressDialog(getActivity());
        progress.setMessage("Fetching data...");
        progress.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_DATA,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progress.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("results");


                            alOnAirTv = new ArrayList<>();
                            for ( int i = 0 ; i < jsonArray.length() ; i++) {
                                JSONObject o = jsonArray.getJSONObject(i);
                                Tv tv = new Tv();
                                tv.setId(o.getInt("id"));
                                tv.setName(o.getString("name"));
                                tv.setDescription(o.getString("overview"));
                                tv.setRating(o.getDouble("vote_average"));
                                tv.setBackground(o.getString("backdrop_path"));
                                tv.setPoster(o.getString("poster_path"));
                                alOnAirTv.add(tv);
                            }

                            Log.i("fetchnya", String.valueOf(alOnAirTv));
                            rvOnAirTv.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
                            TvAdapter tvAdapter = new TvAdapter(getActivity());
                            tvAdapter.setTvList(alOnAirTv);
                            rvOnAirTv.setAdapter(tvAdapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);
    }

    private void fetchPopularTv() {
        final ProgressDialog progress = new ProgressDialog(getActivity());
        progress.setMessage("Fetching data...");
        progress.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_TV_POPULAR,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progress.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("results");


                            alPopularTv = new ArrayList<>();
                            for ( int i = 0 ; i < jsonArray.length() ; i++) {
                                JSONObject o = jsonArray.getJSONObject(i);
                                Tv tv = new Tv();
                                tv.setId(o.getInt("id"));
                                tv.setName(o.getString("name"));
                                tv.setDescription(o.getString("overview"));
                                tv.setRating(o.getDouble("vote_average"));
                                tv.setBackground(o.getString("backdrop_path"));
                                tv.setPoster(o.getString("poster_path"));
                                alPopularTv.add(tv);
                            }

                            rvPopularTv.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
                            TvAdapter tvAdapter = new TvAdapter(getActivity());
                            tvAdapter.setTvList(alPopularTv);
                            rvPopularTv.setAdapter(tvAdapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);
    }

}
