package com.example.moviecatalogue;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderView;
import com.squareup.picasso.Picasso;
import com.synnapps.carouselview.CarouselView;
import com.synnapps.carouselview.ImageListener;
import com.synnapps.carouselview.ViewListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class MovieFragment extends Fragment {

    private static final String URL_DATA = "https://api.themoviedb.org/3/movie/now_playing?sort_by=popularity.desc&api_key=ea8aa5120eed2fdb1d312cf637abf995";
    private static final String URL_POPULAR_MOVIES = "https://api.themoviedb.org/3/movie/popular?sort_by=vote_average.desc&api_key=ea8aa5120eed2fdb1d312cf637abf995";

    private RecyclerView rvMovie;
    private ArrayList<Movie> alMovie;
    private RecyclerView rvPopularMovies;
    private ArrayList<Movie> alPopularMovies;

    CarouselView carouselView;
    String[] sampleImages = {"https://image.tmdb.org/t/p/w500/1TUg5pO1VZ4B0Q1amk3OlXvlpXV.jpg", "https://image.tmdb.org/t/p/w500/m67smI1IIMmYzCl9axvKNULVKLr.jpg"};

    public ImageView setting;

    public MovieFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        ((AppCompatActivity) getActivity()).getSupportActionBar().hide();

        View view = inflater.inflate(R.layout.fragment_movie, container, false);
        view.setNestedScrollingEnabled(true);

        setting = view.findViewById(R.id.setting);
        setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Settings.ACTION_LOCALE_SETTINGS);
                getActivity().startActivity(intent);
            }
        });

        rvMovie = view.findViewById(R.id.movieList);
        rvMovie.setHasFixedSize(true);

        rvPopularMovies = view.findViewById(R.id.popularMoviesList);
        rvPopularMovies.setHasFixedSize(true);

        fetchMovieData();
        fetchPopularMovies();

        carouselView = view.findViewById(R.id.carouselView);
        carouselView.setPageCount(sampleImages.length);
        carouselView.setImageListener(imageListener);

        return view;

    }

    ImageListener imageListener = new ImageListener() {
        @Override
        public void setImageForPosition(int position, ImageView imageView) {
            Picasso
                    .get()
                    .load(sampleImages[position])
                    .into(imageView);
        }
    };

    private void fetchMovieData() {
        final ProgressDialog progress = new ProgressDialog(getActivity());
        progress.setMessage("Fetching data...");
        progress.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_DATA,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progress.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("results");

                            alMovie = new ArrayList<>();
                            for ( int i = 0 ; i < jsonArray.length() ; i++) {
                                JSONObject o = jsonArray.getJSONObject(i);
                                Movie movie = new Movie();
                                movie.setId(o.getInt("id"));
                                movie.setName(o.getString("title"));
                                movie.setDescription(o.getString("overview"));
                                movie.setLanguage(o.getString("original_language"));
                                movie.setRating(o.getDouble("vote_average"));
                                movie.setBackground(o.getString("backdrop_path"));
                                movie.setPoster(o.getString("poster_path"));
                                alMovie.add(movie);
                            }
                            rvMovie.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
                            MovieAdapter movieAdapter = new MovieAdapter(getActivity());
                            movieAdapter.setMovieList(alMovie);
                            rvMovie.setAdapter(movieAdapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);
    }

    private void fetchPopularMovies() {
        final ProgressDialog progress = new ProgressDialog(getActivity());
        progress.setMessage("Fetching data...");
        progress.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_POPULAR_MOVIES,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progress.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("results");

                            alPopularMovies = new ArrayList<>();
                            for ( int i = 0 ; i < jsonArray.length() ; i++) {
                                JSONObject o = jsonArray.getJSONObject(i);
                                Movie movie = new Movie();
                                movie.setId(o.getInt("id"));
                                movie.setName(o.getString("title"));
                                movie.setDescription(o.getString("overview"));
                                movie.setLanguage(o.getString("original_language"));
                                movie.setRating(o.getDouble("vote_average"));
                                movie.setBackground(o.getString("backdrop_path"));
                                movie.setPoster(o.getString("poster_path"));
                                alPopularMovies.add(movie);
                            }
                            rvPopularMovies.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
                            MovieAdapter movieAdapter = new MovieAdapter(getActivity());
                            movieAdapter.setMovieList(alPopularMovies);
                            rvPopularMovies.setAdapter(movieAdapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);
    }

}
