package com.example.moviecatalogue;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class TvAdapter extends RecyclerView.Adapter<TvAdapter.ViewHolder> {

    private Context context;
    private ArrayList<Tv> tvList;

    public TvAdapter(Context context) {
        this.context = context;
    }

    public ArrayList<Tv> getTvList() {
        return tvList;
    }

    public void setTvList(ArrayList<Tv> tvList) {
        this.tvList = tvList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View rowItem = LayoutInflater.from(parent.getContext()).inflate(R.layout.index_item_view, parent, false);
        return new TvAdapter.ViewHolder(rowItem);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, final int i) {

        viewHolder.tvName.setText(getTvList().get(i).getName());

        Picasso
                .get()
                .load(getTvList().get(i).getPoster())
                .into(viewHolder.tvPoster);

        viewHolder.tvContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, TvDetailActivity.class);
                intent.putExtra(TvDetailActivity.EXTRA_MOVIE, (Parcelable) tvList.get(i));
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return getTvList().size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ConstraintLayout tvContainer;
        TextView tvName;
        TextView tvRating;
        ImageView tvPoster;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvContainer = itemView.findViewById(R.id.itemContainer);
            tvName = itemView.findViewById(R.id.itemName);
            tvRating = itemView.findViewById(R.id.itemRating);
            tvPoster = itemView.findViewById(R.id.itemPoster);

        }
    }
}
