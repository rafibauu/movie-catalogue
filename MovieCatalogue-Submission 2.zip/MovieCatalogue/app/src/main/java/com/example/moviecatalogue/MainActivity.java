package com.example.moviecatalogue;

import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.FrameLayout;

public class MainActivity extends AppCompatActivity {

    private FrameLayout MainFrameLayout;

    private BottomNavigationView BottomMainNav;

    private MovieFragment movieFragment;
    private TvFragment tvFragment;
    private LibraryFragment libraryFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MainFrameLayout = findViewById(R.id.main_frame);

        BottomMainNav = findViewById(R.id.bottom_main_nav);

        movieFragment = new MovieFragment();
        tvFragment = new TvFragment();
        libraryFragment = new LibraryFragment();

        setFragment(movieFragment, "Home");

        BottomMainNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            switch ( menuItem.getItemId() ) {
                case R.id.bottom_nav_home :
                    setFragment(movieFragment, "Home");
                    return true;
                case R.id.bottom_nav_tv :
                    setFragment(tvFragment, "Tv Show");
                    return true;
                case R.id.bottom_nav_library :
                    setFragment(libraryFragment, "Library");
                    return true;
                default :
                    return false;
            }
            }
        });

    }

    public void setActionBarTitle(String title) {
        this.setTitle(title);
    }

    private void setFragment(Fragment fragment, String title) {

        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.main_frame, fragment);
        fragmentTransaction.commit();
        setActionBarTitle(title);

    }
}
