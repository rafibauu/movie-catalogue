package com.example.moviecatalogue;

import android.os.Parcel;
import android.os.Parcelable;

public class Mainbanner implements Parcelable {

    private static final String IMAGE_PATH = "https://image.tmdb.org/t/p/";
    private String background;

    public String getBackground() {
        return background;
    }

    public void setBackground(String background) {
        String size = "w500";
        this.background = IMAGE_PATH + size + background;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.background);
    }

    public Mainbanner() {
    }

    protected Mainbanner(Parcel in) {
        this.background = in.readString();
    }

    public static final Parcelable.Creator<Mainbanner> CREATOR = new Parcelable.Creator<Mainbanner>() {
        @Override
        public Mainbanner createFromParcel(Parcel source) {
            return new Mainbanner(source);
        }

        @Override
        public Mainbanner[] newArray(int size) {
            return new Mainbanner[size];
        }
    };
}
